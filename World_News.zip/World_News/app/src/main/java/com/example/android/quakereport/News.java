package com.example.android.quakereport;

public class News {
    private String SectionName;
    private String webTitle;
    private String webPulbicationDate;
    private String Url;
    private String authorname;


    public News(String SectionName, String webTitle) {
        this.SectionName = SectionName;
        this.webTitle = webTitle;
    }

    public News(String SectionName, String webTitle, String webPulbicationDate) {
        this.SectionName = SectionName;
        this.webTitle = webTitle;
        this.webPulbicationDate = webPulbicationDate;
    }

    public News(String SectionName, String webTitle, String webPulbicationDate, String Url) {
        this.SectionName = SectionName;
        this.webTitle = webTitle;
        this.webPulbicationDate = webPulbicationDate;
        this.Url = Url;
    }

    public News(String SectionName, String webTitle, String webPulbicationDate, String Url, String authorname) {
        this.SectionName = SectionName;
        this.webTitle = webTitle;
        this.webPulbicationDate = webPulbicationDate;
        this.Url = Url;
        this.authorname = authorname;
    }

    public String getSectionName() {
        return SectionName;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getWebPulbicationDate() {
        return webPulbicationDate;
    }

    public String getUrl() {return Url; }

    public String getAuthorname() {return authorname;}

}




