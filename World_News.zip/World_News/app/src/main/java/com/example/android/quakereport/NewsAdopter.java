package com.example.android.quakereport;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class NewsAdopter extends ArrayAdapter<News> {
    public NewsAdopter(Activity context, ArrayList<News> words) {
        super(context, 0, words);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Get the {@link Song} object news at this position in the list
        News currentnews = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView NewsTextView = (TextView) listItemView.findViewById(R.id.sectionId);
        // Get the version name from the current Song object and
        // set this text on the name TextView
        NewsTextView.setText(currentnews.getSectionName());

        // Find the TextView in the list_item.xml layout with the ID version_number
        TextView defaultTextView = (TextView) listItemView.findViewById(R.id.webTitle);
        // Get the version number from the Song object and
        // set this text on the number TextView
        defaultTextView.setText(currentnews.getWebTitle());

        TextView phoneTextView = (TextView) listItemView.findViewById(R.id.webPublicationDate);
        // Get the version name from the current Song object and
        // set this text on the name TextView
        phoneTextView.setText(currentnews.getWebPulbicationDate());

        TextView authornameTextView = (TextView) listItemView.findViewById(R.id.authorname);
        // Get the version name from the current Song object and
        // set this text on the name TextView
        authornameTextView.setText(currentnews.getAuthorname());

        // so that it can be shown in the ListView
        return listItemView;
    }
}


